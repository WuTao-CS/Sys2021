#ifndef ACTIVEVARS_H
#define ACTIVEVARS_H
#include "Module.h"

extern void ActiveVars(Module *m);

#endif